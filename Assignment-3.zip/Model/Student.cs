﻿using Assign3.Model.Utilities;
using System;
using Assign3.Model;
using System.Collections.Generic;
using System.Text;
using System.Drawing.Imaging;
using System.IO;
using Microsoft.VisualBasic;
using System.Runtime.InteropServices;
using System.Dynamic;
using System.Threading;
using System.Reflection;
using System.Linq;

namespace Assign3.Model
{
    public class Student

    {
        public string StudentCode { get; set; }
        public string FirstName { get; set; }
        public bool Record { get; set; }
        public string LastName { get; set; }

        private string _DateOfBirthString;
        public string ImageData { get; set; }
        public DateTime DateofBirth { get; set; }
        public static int sum = 0;
        public static int Count2 = 0;
        public static int low;
        public int age;
        public List<int> age1 = new List<int>();
        public string DateOfBirthString
        {
            get
            {
                return _DateOfBirthString;

            }
            set
            {
                _DateOfBirthString = value;
                DateTime datetime;
                if (DateTime.TryParse(_DateOfBirthString, out datetime) == true)
                {
                    DateofBirth = datetime;
                }
            }
        }
       

        public void FromDirectory(string direct)
        {
            string[] directoryPart = direct.Split(" ", StringSplitOptions.None); //Splits the directory part by a space.
            StudentCode = directoryPart[0];
            FirstName = directoryPart[1];
            LastName = directoryPart[2];
            
        }

        public static int abc;
        public void FromCsv(string csvDataLine)
        {
            string[] CsvDataLineParts = csvDataLine.Split(",", StringSplitOptions.None); //Splits the csv by comma.
            DateOfBirthString = CsvDataLineParts[3];
            ImageData = CsvDataLineParts[4];

            //Calculating age.
            string currentyear = DateTime.Now.Year.ToString(); //Takes the current year.
            try
            {
                int x = int.Parse(currentyear);    //Converts the string to int type.
                int p = DateOfBirthString.Length - 2; //Takes the index of the second element from the last.
                int y = int.Parse(DateOfBirthString.Substring(p)); //y takes only substrings For example in 18/10/1997 or 10/18/1997 only 97 is taken.
                if (y < 50)     //If y<50, the user has given the input in the format 1997/10/18.
                {
                    y = int.Parse(DateOfBirthString.Substring(2, 2));  //So, taking the 3th and 4th element.

                }
                int age = x - (1900 + y);   //Adding 1900 to y and subtracting from 2020. i.e 2020-1997

                //loop to find the maximum age.
                if (abc<age)
                {
                    abc = age;
                }
                //Condition to find the minimum age.
                if(low>age || low==0)
                {
                    low = age;
                }
                age1.Add(age);
            }
            catch
            {
                //If the user doesn't enter the age, then by default 0 is set.
                age1.Add(0);
            }

            foreach (int i in age1)
            {
                //Console.WriteLine(i);
                if (i > 0)
                {
                    sum = sum + i;
                    Count2 = Count2 + 1;
                }
            }

            //Creates a csv file named infox1 and continoues adds the data to it.
            
            

           

        }

        

        
           
        public override string ToString()
        {
            return $"{StudentCode}-{FirstName},{LastName},{DateOfBirthString},{Record}";


        }

        
        public static int avg;
        public static int lowe;

        //Function for calculating the average of the age.
        public static int average()
        {
            avg = sum / Count2;
            Console.WriteLine(avg);
            return avg;
      
        }

        public static int high;

        //Function for calculating the highest in the age.
        public static int highest()
        {
            high = abc;
            return (high);
        }


        //Function for calculating the lowest in the age.
        public static int lowest()
        {
            lowe = low;
            return low;
        }


        //Displays the content in csv format.
    public string ToCSV()
        {
            //Below commented code is the part of the program, commented it to prevent overwriting everytime I run the program.
            //string docPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            //using (StreamWriter outputFile = new StreamWriter(Path.Combine(docPath, "students.csv"), true)) //true indicates it supports overwriting.
            //{

            //    outputFile.WriteLine(StudentCode.Trim() + "," + FirstName.Trim() + "," + LastName.Trim() + "," + Record);

            //}
            string result = $"{StudentCode},{FirstName},{LastName},{DateOfBirthString},{Record}";
            return result;
        }



    }



}
