﻿namespace Assign3.Model
{
    public class List
    {
    }
}